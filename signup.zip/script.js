const Form= document.querySelector('#form');
const pass= document.querySelector('#pass');
const cpass= document.querySelector('#cpass');
const err= document.querySelector('.error');
const scuess= document.querySelector('.Sucess');

Form.addEventListener('submit',onSubmit)

function onSubmit(e){
  e.preventDefault();
   if (pass.value!=cpass.value) {
       err.innerHTML="Passwords not matching";
       // setTimeout(()=>err.remove(),2000);
       pass.value="";
       cpass.value="";
   }
   else{
     err.innerHTML="";
       scuess.innerHTML="Account made";
        setTimeout(()=>scuess.remove(),2000);
        pass.value="";
        cpass.value="";
   }
}
